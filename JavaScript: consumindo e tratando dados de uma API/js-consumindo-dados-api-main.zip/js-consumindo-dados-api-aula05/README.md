<p align="center"> <img src="https://imgur.com/KXUnUsg.png" alt="HTML e CSS: praticando HTML e CSS"> </p>

<hr>

<p align="center"> <img src="https://github.com/MonicaHillman/js-consumindo-dados-api/blob/aula05/img/Logo.svg" alt="Logo da alura books"> </p>
<p align="center">Um formulário de cadastro da plataforma AluraBooks, uma livraria on-line que vende livros técnicos. Nesse formulário implementamos o auto preenchimento de informações do endereço através do valor do CEP inserido pelo usuário.</p>

## Tecnologias utilizadas durante o curso
* Javascript

## Tecnologias utilizadas no projeto
* HTML
* CSS

## Screenshots
![Screenshot da tela do formulário do AluraBooks](https://imgur.com/bupnUfx.png)
